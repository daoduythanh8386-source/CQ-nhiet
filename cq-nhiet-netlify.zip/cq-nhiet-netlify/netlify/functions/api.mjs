// CQ Nhiet – máy chủ nhỏ: lưu tài khoản, người ký, con dấu, dữ liệu CQ, lịch sử trên Netlify Blobs.
// Mọi máy mở cùng một link sẽ dùng chung dữ liệu; cập nhật app (deploy mới) không làm mất dữ liệu.
const KEYS=['accts','people','stamps','pos','extra','domain','gd','data'];
const ADMIN_ONLY=new Set(['people','stamps','domain','gd']);
const SESSION_MS=14*24*3600*1000;
const enc=new TextEncoder();
const J=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});
async function sha256(s){const b=await crypto.subtle.digest('SHA-256',enc.encode(s));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');}
const rnd=n=>{const a=new Uint8Array(n);crypto.getRandomValues(a);return [...a].map(x=>x.toString(16).padStart(2,'0')).join('');};
const str=(v,n)=>String(v==null?'':v).slice(0,n);
const lc=s=>String(s||'').trim().toLowerCase();
const unameOf=a=>lc(a.user||a.email);

let STORE=null;
// Dự phòng: nếu không nạp được gói @netlify/blobs thì gọi thẳng API Blobs bằng thông tin môi trường Netlify cấp cho hàm.
function restStore(){
  const raw=(typeof process!=='undefined'&&process.env&&process.env.NETLIFY_BLOBS_CONTEXT)||globalThis.netlifyBlobsContext;
  if(!raw)throw new Error('Không có NETLIFY_BLOBS_CONTEXT');
  const c=typeof raw==='string'?JSON.parse(atob(raw)):raw;
  if(!c.edgeURL||!c.token||!c.siteID)throw new Error('Thiếu thông tin Blobs');
  const nm='site:cq-nhiet';
  const u=k=>new URL('/'+c.siteID+'/'+nm+(k?'/'+encodeURIComponent(k):''),c.edgeURL);
  const h={authorization:'Bearer '+c.token};
  return{
    async get(k,o){const r=await fetch(u(k),{headers:h});if(r.status===404)return null;if(!r.ok)throw new Error('blobs get '+r.status);return o&&o.type==='json'?await r.json():await r.text();},
    async setJSON(k,v){const r=await fetch(u(k),{method:'PUT',headers:h,body:JSON.stringify(v)});if(!r.ok)throw new Error('blobs set '+r.status);},
    async delete(k){await fetch(u(k),{method:'DELETE',headers:h});},
    async list(o){const x=u('');if(o&&o.prefix)x.searchParams.set('prefix',o.prefix);const r=await fetch(x,{headers:h});if(!r.ok)throw new Error('blobs list '+r.status);const j=await r.json();return{blobs:j.blobs||[]};}
  };
}
async function store(){
  if(globalThis.__CQ_TEST_STORE)return globalThis.__CQ_TEST_STORE;
  if(STORE)return STORE;
  try{const m=await import('@netlify/blobs');STORE=m.getStore({name:'cq-nhiet',consistency:'strong'});}
  catch(e){STORE=restStore();}
  return STORE;
}
const getJ=async(s,k)=>{const v=await s.get(k,{type:'json'});return v==null?null:v;};
const setJ=(s,k,v)=>s.setJSON?s.setJSON(k,v):s.set(k,JSON.stringify(v));

function cleanAcct(a){
  return{id:str(a.id,40),user:str(a.user,60),name:str(a.name,100),phone:str(a.phone,20),email:str(a.email,120),role:a.role==='admin'?'admin':'user',
    salt:str(a.salt,64),hash:str(a.hash,200),created:+a.created||0,last:a.last==null?null:(+a.last||0),must:!!a.must,rs:str(a.rs,40),rhash:str(a.rhash,200),mt:+a.mt||0};
}
function viewFor(v,me){
  const o={};
  for(const k of KEYS){
    if(k==='accts')o[k]=me.role==='admin'?v.accts:v.accts.filter(a=>a.id===me.id);
    else o[k]=v[k]===undefined?null:v[k];
  }
  return o;
}
async function session(s,tok){
  if(!tok||typeof tok!=='string'||tok.length<20)return null;
  const k='sess/'+await sha256(tok);const x=await getJ(s,k);
  if(!x||x.exp<Date.now())return null;
  const v=await getJ(s,'vault');const me=v&&v.accts.find(a=>a.id===x.uid);
  return me?{me,v,k}:null;
}
async function newSession(s,uid){
  const tok=rnd(32);await setJ(s,'sess/'+await sha256(tok),{uid,exp:Date.now()+SESSION_MS});return tok;
}
const monthOf=t=>{const d=new Date(t);return d.getUTCFullYear()+'-'+String(d.getUTCMonth()+1).padStart(2,'0');};
const logKey=x=>x.t+'|'+x.e+'|'+x.a+'|'+x.d;
async function addLogs(s,entries){
  const by={};
  for(const x of entries){if(!x||!(+x.t))continue;const m=monthOf(+x.t);(by[m]||(by[m]=[])).push({t:+x.t,u:str(x.u,100),e:str(x.e,120),ty:str(x.ty,40),a:str(x.a,200),d:str(x.d,1500)});}
  for(const m of Object.keys(by)){
    const cur=(await getJ(s,'log/'+m))||[];const seen=new Set(cur.map(logKey));let ch=false;
    for(const x of by[m]){const k=logKey(x);if(!seen.has(k)){seen.add(k);cur.push(x);ch=true;}}
    if(ch){cur.sort((a,b)=>a.t-b.t);await setJ(s,'log/'+m,cur);}
  }
}
async function failState(s,user){const k='fail/'+await sha256(lc(user));return{k,v:(await getJ(s,k))||{n:0,until:0}};}

const esc=t=>String(t==null?'':t).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const phn=x=>String(x||'').replace(/\D/g,'').replace(/^84/,'0');
async function sendMail(to,subject,html,text){
  const env=(typeof process!=='undefined'&&process.env)||{};
  const from=env.MAIL_FROM,fname=env.MAIL_FROM_NAME||'CQ Nhiet - Oristar';
  if(!from||!(env.BREVO_API_KEY||env.RESEND_API_KEY))return{ok:false,e:'nocfg'};
  to=[...new Set(to.filter(Boolean))];if(!to.length)return{ok:false,e:'noto'};
  try{
    if(env.BREVO_API_KEY){
      const r=await fetch('https://api.brevo.com/v3/smtp/email',{method:'POST',headers:{'api-key':env.BREVO_API_KEY,'content-type':'application/json',accept:'application/json'},body:JSON.stringify({sender:{name:fname,email:from},to:to.map(e=>({email:e})),subject,htmlContent:html,textContent:text})});
      return r.ok?{ok:true}:{ok:false,e:'Brevo '+r.status+' '+(await r.text()).slice(0,160)};
    }
    const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{authorization:'Bearer '+env.RESEND_API_KEY,'content-type':'application/json'},body:JSON.stringify({from:fname+' <'+from+'>',to,subject,html,text})});
    return r.ok?{ok:true}:{ok:false,e:'Resend '+r.status+' '+(await r.text()).slice(0,160)};
  }catch(e){return{ok:false,e:String(e&&e.message||e).slice(0,160)};}
}
async function rstList(s){
  const ks=(await s.list({prefix:'rst/'})).blobs.map(x=>x.key);const out=[];const cut=Date.now()-7*864e5;
  for(const k of ks.slice(-200)){const r=await getJ(s,k);if(r&&r.t>cut)out.push(r);}
  return out.sort((a,b)=>b.t-a.t);
}
const RST_GENERIC='Nếu thông tin khớp với tài khoản, yêu cầu đã được gửi tới email của Admin. Khi Admin chấp nhận, một email chứa link đặt mật khẩu mới (hiệu lực 30 phút) sẽ được gửi tới đúng email bạn đã đăng ký.';
export default async (req)=>{
  try{
    if(req.method!=='POST')return J({ok:false,e:'method'},405);
    let b;try{b=await req.json();}catch(e){return J({ok:false,e:'json'},400);}
    const a=b.a;let s;
    try{s=await store();}catch(e){return J({ok:false,e:'storage',msg:String(e&&e.message||e).slice(0,300)},200);}
    let v=null;
    try{v=await getJ(s,'vault');}catch(e){return J({ok:false,e:'storage',msg:String(e&&e.message||e).slice(0,300)},200);}

    if(a==='status')return J({ok:true,init:!!(v&&v.accts&&v.accts.length)});

    if(a==='salt'){
      const u=lc(b.user);const ac=v&&v.accts.find(x=>unameOf(x)===u||lc(x.email)===u);
      return J({ok:true,salt:ac?ac.salt:(await sha256('fake'+u)).slice(0,20)});
    }

    if(a==='setup'){
      if(v&&v.accts&&v.accts.length)return J({ok:false,e:'Máy chủ đã có tài khoản – hãy đăng nhập.'});
      const sn=b.snap||{};const accts=(Array.isArray(sn.accts)?sn.accts:[]).map(cleanAcct).filter(x=>x.id&&x.salt&&x.hash&&x.email);
      if(!accts.some(x=>x.role==='admin'))return J({ok:false,e:'Thiếu tài khoản admin.'});
      const nv={v:{}};for(const k of KEYS){nv[k]=k==='accts'?accts:(sn[k]===undefined?null:sn[k]);nv.v[k]=1;}nv.v.orig=0;
      await setJ(s,'vault',nv);
      const me=accts.find(x=>x.role==='admin'&&x.id===str(b.me,40))||accts.find(x=>x.role==='admin');
      return J({ok:true,tok:await newSession(s,me.id),me:me.id});
    }

    if(a==='login'){
      const u=lc(b.user);const f=await failState(s,u);
      if(f.v.until>Date.now())return J({ok:false,e:'Nhập sai nhiều lần – thử lại sau '+Math.ceil((f.v.until-Date.now())/1000)+' giây.'});
      const ac=v&&v.accts.find(x=>unameOf(x)===u||lc(x.email)===u);
      if(ac&&typeof b.hash==='string'&&b.hash&&b.hash===ac.hash){
        if(f.v.n){await s.delete(f.k);}
        ac.last=Date.now();ac.mt=Date.now();v.v.accts=(v.v.accts||0)+1;await setJ(s,'vault',v);
        return J({ok:true,tok:await newSession(s,ac.id),me:ac.id});
      }
      const n=(f.v.n||0)+1;await setJ(s,f.k,n>=5?{n:0,until:Date.now()+60000}:{n,until:0});
      await addLogs(s,[{t:Date.now(),u:ac?ac.name:'(không rõ)',e:ac?ac.email:str(b.user,120),ty:'Tài khoản',a:'Đăng nhập thất bại',d:''}]);
      return J({ok:false,e:n>=5?'Sai 5 lần – khoá đăng nhập 60 giây.':'Sai tên đăng nhập hoặc mật khẩu.'});
    }

    if(a==='recover'){ // admin quên mật khẩu: dùng mã khôi phục
      const u=lc(b.user);const ac=v&&v.accts.find(x=>unameOf(x)===u||lc(x.email)===u);
      const f=await failState(s,'rc:'+u);if(f.v.until>Date.now())return J({ok:false,e:'Thử lại sau ít phút.'});
      if(!ac||!ac.rs||!ac.rhash||(await sha256(ac.rs+str(b.rc,40).trim().toUpperCase()))!==ac.rhash){
        const n=(f.v.n||0)+1;await setJ(s,f.k,n>=5?{n:0,until:Date.now()+300000}:{n,until:0});return J({ok:false,e:'Tên đăng nhập hoặc mã khôi phục không đúng.'});}
      if(!str(b.salt,64)||!str(b.hash,200))return J({ok:false,e:'Thiếu dữ liệu.'});
      ac.salt=str(b.salt,64);ac.hash=str(b.hash,200);ac.must=false;ac.mt=Date.now();v.v.accts=(v.v.accts||0)+1;await setJ(s,'vault',v);
      return J({ok:true});
    }

    if(a==='rstreq'){
      const u=lc(b.user),em=lc(b.email);
      const ac=v&&v.accts.find(x=>unameOf(x)===u||lc(x.email)===u);
      if(!ac||lc(ac.email)!==em||!phn(b.phone)||phn(ac.phone)!==phn(b.phone)){
        await addLogs(s,[{t:Date.now(),u:'(không rõ)',e:str(b.email,120),ty:'Tài khoản',a:'Yêu cầu đặt lại mật khẩu sai thông tin',d:str(b.user,60)}]);
        return J({ok:true,msg:RST_GENERIC});
      }
      const list=await rstList(s);const recent=list.filter(x=>x.uid===ac.id&&x.t>Date.now()-3600e3);
      if(recent.some(x=>x.st==='pending')||recent.length>=3)return J({ok:true,msg:RST_GENERIC});
      const id=rnd(8);
      await setJ(s,'rst/'+id,{id,uid:ac.id,name:ac.name,user:ac.user,email:ac.email,phone:ac.phone,t:Date.now(),st:'pending'});
      const admins=v.accts.filter(x=>x.role==='admin'&&x.email).map(x=>x.email);
      const site=process.env.URL||new URL(req.url).origin;
      const html='<p><b>'+esc(ac.name)+'</b> (tên đăng nhập <b>'+esc(ac.user||ac.email)+'</b>, email '+esc(ac.email)+', SĐT '+esc(ac.phone)+') vừa gửi yêu cầu <b>đặt lại mật khẩu</b> trên app CQ Nhiệt.</p><p>Mở app, đăng nhập Admin → tab <b>Tài khoản</b> → mục <b>Yêu cầu đặt lại mật khẩu</b> → bấm <b>Chấp nhận</b> hoặc <b>Từ chối</b>.<br><a href="'+esc(site)+'">'+esc(site)+'</a></p><p>Nếu bạn không biết người này, hãy bấm Từ chối hoặc bỏ qua – mật khẩu không bị thay đổi.</p>';
      const mr=await sendMail(admins,'CQ Nhiệt: '+ac.name+' xin đặt lại mật khẩu',html,ac.name+' ('+(ac.user||ac.email)+') xin đặt lại mật khẩu. Đăng nhập Admin tại '+site+' > Tài khoản > Yêu cầu đặt lại mật khẩu để chấp nhận hoặc từ chối.');
      await addLogs(s,[{t:Date.now(),u:ac.name,e:ac.email,ty:'Tài khoản',a:'Gửi yêu cầu đặt lại mật khẩu',d:mr.ok?'Đã báo email Admin':'Chưa gửi được email Admin ('+(mr.e==='nocfg'?'chưa cấu hình dịch vụ email':mr.e)+')'}]);
      return J({ok:true,msg:RST_GENERIC});
    }
    if(a==='rstnew'){
      const rec=await getJ(s,'rst/'+str(b.id,20));const bad=J({ok:false,e:'Link đặt lại mật khẩu không hợp lệ, đã dùng hoặc đã hết hạn (30 phút). Hãy gửi yêu cầu mới.'});
      if(!rec||rec.st!=='approved'||!rec.th||rec.exp<Date.now()||(await sha256(str(b.tok,80)))!==rec.th)return bad;
      const ac=v&&v.accts.find(x=>x.id===rec.uid);if(!ac)return bad;
      if(b.check)return J({ok:true,name:ac.name});
      if(!str(b.salt,64)||!str(b.hash,200))return J({ok:false,e:'Thiếu dữ liệu.'});
      ac.salt=str(b.salt,64);ac.hash=str(b.hash,200);ac.must=false;ac.mt=Date.now();v.v.accts=(v.v.accts||0)+1;await setJ(s,'vault',v);
      rec.st='done';rec.th='';rec.done=Date.now();await setJ(s,'rst/'+rec.id,rec);
      await addLogs(s,[{t:Date.now(),u:ac.name,e:ac.email,ty:'Tài khoản',a:'Tự đặt mật khẩu mới qua email được Admin chấp nhận',d:''}]);
      return J({ok:true});
    }

    // ---- cần đăng nhập ----
    const ss=await session(s,b.tok);
    if(!ss)return J({ok:false,e:'auth'},401);
    const me=ss.me,isAdm=me.role==='admin';v=ss.v;

    if(a==='rstlist'){
      if(!isAdm)return J({ok:false,e:'Chỉ Admin.'},403);
      const list=(await rstList(s)).map(x=>({id:x.id,name:x.name,user:x.user,email:x.email,phone:x.phone,t:x.t,st:x.st==='approved'&&x.exp<Date.now()?'expired':x.st,by:x.by||''}));
      return J({ok:true,list});
    }
    if(a==='rstact'){
      if(!isAdm)return J({ok:false,e:'Chỉ Admin.'},403);
      const rec=await getJ(s,'rst/'+str(b.id,20));if(!rec||rec.st!=='pending')return J({ok:false,e:'Yêu cầu không còn ở trạng thái chờ.'});
      const ac=v.accts.find(x=>x.id===rec.uid);if(!ac)return J({ok:false,e:'Tài khoản không còn tồn tại.'});
      rec.by=me.name;
      if(!b.accept){rec.st='denied';await setJ(s,'rst/'+rec.id,rec);await addLogs(s,[{t:Date.now(),u:me.name,e:me.email,ty:'Tài khoản',a:'Từ chối yêu cầu đặt lại mật khẩu',d:ac.email}]);return J({ok:true,denied:true});}
      const tok=rnd(24);rec.st='approved';rec.th=await sha256(tok);rec.exp=Date.now()+30*60000;await setJ(s,'rst/'+rec.id,rec);
      const site=process.env.URL||new URL(req.url).origin;const link=site+'/?reset='+tok+'&rid='+rec.id;
      const html='<p>Chào <b>'+esc(ac.name)+'</b>,</p><p>Admin đã chấp nhận yêu cầu đặt lại mật khẩu CQ Nhiệt của bạn. Bấm vào link dưới đây để tự đặt mật khẩu mới (link dùng một lần, hiệu lực <b>30 phút</b>):</p><p><a href="'+esc(link)+'">Đặt mật khẩu mới</a></p><p style="color:#666;font-size:12px">Nếu bạn không yêu cầu việc này, hãy bỏ qua email – mật khẩu cũ vẫn dùng được.</p>';
      const mr=await sendMail([ac.email],'CQ Nhiệt: link đặt lại mật khẩu',html,'Admin đã chấp nhận yêu cầu. Mở link để đặt mật khẩu mới (30 phút, dùng một lần): '+link);
      await addLogs(s,[{t:Date.now(),u:me.name,e:me.email,ty:'Tài khoản',a:'Chấp nhận yêu cầu đặt lại mật khẩu',d:ac.email+(mr.ok?' – đã gửi email':' – chưa gửi được email')}]);
      if(mr.ok)return J({ok:true,sent:true,to:ac.email});
      return J({ok:true,sent:false,link,reason:mr.e==='nocfg'?'Chưa cấu hình dịch vụ gửi email trên Netlify.':mr.e});
    }
    if(a==='logout'){await s.delete(ss.k);return J({ok:true});}

    if(a==='pull'){
      const have=b.ver||{};const ch={};
      for(const k of KEYS){if((v.v[k]||0)>(+have[k]||0)){ch[k]=viewFor(v,me)[k];}}
      return J({ok:true,me:me.id,role:me.role,changed:ch,ver:v.v});
    }

    if(a==='getkey'){
      if(!KEYS.includes(b.key))return J({ok:false,e:'key'});
      return J({ok:true,val:viewFor(v,me)[b.key],v:v.v[b.key]||0});
    }

    if(a==='push'){
      const k=b.key;if(!KEYS.includes(k))return J({ok:false,e:'key'});
      if(ADMIN_ONLY.has(k)&&!isAdm)return J({ok:false,e:'Chỉ Admin được sửa mục này.'},403);
      if(JSON.stringify(b.val||null).length>5200000)return J({ok:false,e:'Dữ liệu quá lớn.'});
      if(k==='accts'){
        const cur=new Map(v.accts.map(x=>[x.id,x]));
        if(!isAdm){ // thành viên: chỉ đổi được bản ghi của chính mình (mật khẩu, lần đăng nhập)
          const mine=(Array.isArray(b.val)?b.val:[]).find(x=>x&&x.id===me.id);
          if(mine){const m=cleanAcct(mine);if(m.mt>=(me.mt||0)){Object.assign(me,{salt:m.salt||me.salt,hash:m.hash||me.hash,must:m.must,last:m.last,mt:m.mt});}}
          v.v.accts=(v.v.accts||0)+1;await setJ(s,'vault',v);return J({ok:true,v:v.v.accts});
        }
        const del=new Set(Array.isArray(b.del)?b.del.map(x=>str(x,40)):[]);const out=[],seen=new Set();
        for(const x of (Array.isArray(b.val)?b.val:[])){
          const n=cleanAcct(x);if(!n.id||!n.email||!n.salt||!n.hash)continue;seen.add(n.id);const c=cur.get(n.id);
          out.push(!c?n:(n.mt>=(c.mt||0)?Object.assign({},c,n):c));
        }
        for(const c of v.accts)if(!seen.has(c.id)&&!del.has(c.id))out.push(c);
        if(!out.some(x=>x.role==='admin'))return J({ok:false,e:'Phải còn ít nhất 1 admin.'});
        v.accts=out;v.v.accts=(v.v.accts||0)+1;await setJ(s,'vault',v);
        return J({ok:true,v:v.v.accts,accts:out});
      }
      if(k==='data'&&(+b.base||0)<(v.v.data||0))return J({ok:false,conflict:true,v:v.v.data});
      v[k]=b.val===undefined?null:b.val;v.v[k]=(v.v[k]||0)+1;await setJ(s,'vault',v);
      return J({ok:true,v:v.v[k]});
    }

    if(a==='pushorig'){ // file gốc gửi theo từng mảnh nhỏ (giới hạn ~6MB mỗi lần gọi hàm)
      const i=+b.i||0,n=+b.n||1,b64=String(b.b64||'');
      if(!b64||b64.length>2500000||i<0||i>=n||n>40)return J({ok:false,e:'Mảnh file không hợp lệ.'});
      await setJ(s,'orig/'+i,{b64});
      if(i===n-1){await setJ(s,'orig',{name:str(b.name,200),n,by:me.name,t:Date.now()});v.v.orig=(v.v.orig||0)+1;await setJ(s,'vault',v);}
      return J({ok:true,v:v.v.orig||0,done:i===n-1});
    }
    if(a==='getorig'){
      const o=await getJ(s,'orig');if(!o)return J({ok:false,e:'none'});
      if(b.i==null)return J({ok:true,name:o.name,n:o.n||1,v:v.v.orig||0});
      const c=await getJ(s,'orig/'+(+b.i||0));if(!c)return J({ok:false,e:'none'});
      return J({ok:true,b64:c.b64,v:v.v.orig||0});
    }

    if(a==='logadd'){
      const es=(Array.isArray(b.entries)?b.entries:[]).slice(0,3000).map(x=>Object.assign({},x,{e:me.email,u:me.name}));
      // thành viên chỉ ghi lịch sử của chính mình; admin giữ nguyên tên/mail đã ghi (khi chuyển dữ liệu cũ lên)
      const fin=isAdm&&b.keepIdentity?(Array.isArray(b.entries)?b.entries.slice(0,3000):[]):es;
      await addLogs(s,fin);return J({ok:true,n:fin.length});
    }
    if(a==='logpull'){
      const since=+b.since||0;const names=(await s.list({prefix:'log/'})).blobs.map(x=>x.key).sort();
      const from=monthOf(since||0);const out=[];
      for(const k of names){if(k.slice(4)<from)continue;const arr=(await getJ(s,k))||[];for(const x of arr){if(x.t>since&&(isAdm||x.e===me.email))out.push(x);}}
      out.sort((p,q)=>p.t-q.t);return J({ok:true,entries:out.slice(-30000)});
    }
    return J({ok:false,e:'action'},400);
  }catch(e){
    return J({ok:false,e:'server',msg:String(e&&e.message||e).slice(0,300)},500);
  }
};
